<?php
include_once("conexao.php");

$nome = $_POST['nome'];
$email = $_POST['email'];
$senha = $_POST['senha'];

$sql = "INSERT INTO tb_usuario (nome, email, senha) VALUES ('$nome', '$email', '$senha')";
$conn->query($sql);

header("Location: cadastro-usuario.html");
?>
