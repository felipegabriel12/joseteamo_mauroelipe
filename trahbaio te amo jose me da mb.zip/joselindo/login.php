<?php
session_start();
include_once("conexao.php");

if(isset($_POST['email']) && isset($_POST['senha'])) {
    
    $email = $_POST['email'];
    $senha = $_POST['senha'];

    $sql = "SELECT * FROM tb_usuario WHERE email='$email' AND senha='$senha'";
    $result = $conn->query($sql);

    if($result->num_rows > 0){
        $_SESSION['usuario'] = $email;
        header("Location: home.html");
        exit();
    } else {
        header("Location: index.html?erro=1");
        exit();
    }
}
?>
