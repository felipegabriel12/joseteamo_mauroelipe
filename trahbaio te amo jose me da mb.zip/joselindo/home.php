<?php
include_once("conexao.php");
?>

<!DOCTYPE html>
<html lang="pt-br">
<head>
    <meta charset="UTF-8">
    <link rel="stylesheet" href="style.css">
    <title>Home</title>
</head>
<body>

<header>Sistema de Estoque - Home</header>

<nav>
    <a href="cadastro-usuario.html">Usuários</a>
    <a href="cadastro-produto.html">Produtos</a>
    <a href="cadastro-fornecedor.html">Fornecedores</a>
    <a href="movimentacao.html">Movimentação</a>
    <a href="index.html">Sair</a>
</nav>

<div class="container">
    <h2>Registros do Sistema</h2>

    <!-- USUÁRIOS -->
    <h3>Usuários cadastrados</h3>
    <table border="1" width="100%">
        <tr><th>ID</th><th>Nome</th><th>Email</th></tr>
        <?php
        $sql = "SELECT * FROM tb_usuario";
        $res = $conn->query($sql);
        while($row = $res->fetch_assoc()){
            echo "<tr>
                    <td>".$row['id']."</td>
                    <td>".$row['nome']."</td>
                    <td>".$row['email']."</td>
                  </tr>";
        }
        ?>
    </table>

    <br>

    <!-- PRODUTOS -->
    <h3>Produtos cadastrados</h3>
    <table border="1" width="100%">
        <tr><th>ID</th><th>Produto</th><th>Quantidade</th><th>Preço</th></tr>
        <?php
        $sql = "SELECT * FROM tb_produto";
        $res = $conn->query($sql);
        while($row = $res->fetch_assoc()){
            echo "<tr>
                    <td>".$row['id']."</td>
                    <td>".$row['nome']."</td>
                    <td>".$row['quantidade']."</td>
                    <td>".$row['preco']."</td>
                  </tr>";
        }
        ?>
    </table>

    <br>

    <!-- FORNECEDORES -->
    <h3>Fornecedores cadastrados</h3>
    <table border="1" width="100%">
        <tr><th>ID</th><th>Fornecedor</th><th>CNPJ</th></tr>
        <?php
        $sql = "SELECT * FROM tb_fornecedor";
        $res = $conn->query($sql);
        while($row = $res->fetch_assoc()){
            echo "<tr>
                    <td>".$row['id']."</td>
                    <td>".$row['nome']."</td>
                    <td>".$row['cnpj']."</td>
                  </tr>";
        }
        ?>
    </table>

    <br>

    <!-- MOVIMENTAÇÕES -->
    <h3>Movimentações de estoque</h3>
    <table border="1" width="100%">
        <tr><th>ID</th><th>Tipo</th><th>Produto</th><th>Quantidade</th></tr>
        <?php
        $sql = "SELECT * FROM tb_movimentacao";
        $res = $conn->query($sql);
        while($row = $res->fetch_assoc()){
            echo "<tr>
                    <td>".$row['id']."</td>
                    <td>".$row['tipo']."</td>
                    <td>".$row['produto']."</td>
                    <td>".$row['quantidade']."</td>
                  </tr>";
        }
        ?>
    </table>

</div>

</body>
</html>
