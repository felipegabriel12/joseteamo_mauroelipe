<?php
include_once("conexao.php");

$tipo = $_POST['tipo'];
$produto = $_POST['produto'];
$quantidade = $_POST['quantidade'];

$sql = "INSERT INTO tb_movimentacao (tipo, produto, quantidade)
        VALUES ('$tipo', '$produto', '$quantidade')";

$conn->query($sql);

header("Location: home.php");
?>
