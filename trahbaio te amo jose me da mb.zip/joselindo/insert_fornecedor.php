<?php
include_once("conexao.php");

$nome = $_POST['nome'];
$cnpj = $_POST['cnpj'];

$sql = "INSERT INTO tb_fornecedor (nome, cnpj)
        VALUES ('$nome', '$cnpj')";

$conn->query($sql);

header("Location: home.php");
?>
