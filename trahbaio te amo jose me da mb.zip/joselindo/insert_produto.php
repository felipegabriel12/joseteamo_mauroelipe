<?php
include_once("conexao.php");

$nome = $_POST['nome'];
$quantidade = $_POST['quantidade'];
$preco = $_POST['preco'];

$sql = "INSERT INTO tb_produto (nome, quantidade, preco) 
        VALUES ('$nome', '$quantidade', '$preco')";

$conn->query($sql);

header("Location: home.php");
?>
