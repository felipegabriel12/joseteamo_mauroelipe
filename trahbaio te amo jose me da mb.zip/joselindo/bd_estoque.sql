create database db_estoque;
use db_estoque;

CREATE TABLE tb_usuario (
    id INT AUTO_INCREMENT PRIMARY KEY,
    nome VARCHAR(100) NOT NULL,
    email VARCHAR(100) NOT NULL UNIQUE,
    senha VARCHAR(255) NOT NULL,
    data_cadastro TIMESTAMP DEFAULT CURRENT_TIMESTAMP
);

CREATE TABLE tb_produto (
    id INT AUTO_INCREMENT PRIMARY KEY,
    nome VARCHAR(100),
    quantidade INT,
    preco DECIMAL(10,2)
);

CREATE TABLE tb_fornecedor (
    id INT AUTO_INCREMENT PRIMARY KEY,
    nome VARCHAR(100),
    cnpj VARCHAR(30)
);

CREATE TABLE tb_movimentacao (
    id INT AUTO_INCREMENT PRIMARY KEY,
    tipo VARCHAR(20),
    produto VARCHAR(100),
    quantidade INT
);

